<?php
include 'db_details.php';

 date_default_timezone_set("Asia/Kolkata");
$dbc = mysqli_connect($host, $username, $password, $database);
if (!$dbc) {
    die("Database connection failed: " . mysqli_error($dbc));
    exit();
}

$dbs = mysqli_select_db($dbc, $database);
if (!$dbs) {
    die("Database selection failed: " . mysqli_error($dbc));
    exit(); 
}


$values = mysqli_query($dbc, "SELECT dates,email,id,lat,longi,installation,service FROM `devices_users` WHERE email='".$_GET["email"]."' ");
$yourArray = array(); // make a new array to hold all your data
$index = 0;
while($row = mysqli_fetch_assoc($values)){ // loop to store the data in an associative array.
     $yourArray[$index] = $row;
     $index++;
}


 echo '[{"dates":"'.$yourArray[0]['dates'].'","email":"'.$yourArray[0]['email'].'","id":"'.$yourArray[0]['id'].'","lat":"'.$yourArray[0]['lat'].'","longi":"'.$yourArray[0]['longi'].'","installation":"'.$yourArray[0]['installation'].'","service":"'.$yourArray[0]['service'].'"}]';
 ?>