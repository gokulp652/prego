<?php
$host ="localhost";
$username="root";
$password="";
$database="smartkitchen";

?>