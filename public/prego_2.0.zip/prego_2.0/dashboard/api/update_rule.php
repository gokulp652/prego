<?php

include 'db_details.php';
date_default_timezone_set("Asia/Kolkata");
$link = mysqli_connect($host, $username, $password, $database);
//$link = mysqli_connect("localhost", "4fit", "motorinkz2016", "4fit_motorinkz");

 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$date = date('Y-m-d H:i:s');


// Attempt insert query execution
//$sql ="INSERT INTO `prago_dish` (dates,dish_id,button1,remarks1,button2,remarks2,button3,remarks3,button4,dish,added_by) VALUES ('$date','".$_GET["dish_id"]."','".$_GET["button1"]."','".$_GET["remarks1"]."','".$_GET["button2"]."','".$_GET["remarks2"]."','".$_GET["button3"]."','".$_GET["remarks3"]."','".$_GET["button4"]."','".$_GET["dish"]."','".$_GET["added_by"]."')";
$sql = "UPDATE prago_dish SET dates='$date',button1='".$_GET["button1"]."', remarks1='".$_GET["remarks1"]."', button2='".$_GET["button2"]."', remarks2='".$_GET["remarks2"]."', button3='".$_GET["button3"]."', remarks3='".$_GET["remarks3"]."', button4='".$_GET["button4"]."', dish='".$_GET["dish"]."',added_by='".$_GET["added_by"]."' WHERE dish_id='".$_GET["dish_id"]."'";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

 $sql = "UPDATE prago_dish_list SET dates='$date',dish='".$_GET["dish"]."', added_by='".$_GET["added_by"]."', dish_time='".$_GET["remarks2"]."' WHERE dish_id='".$_GET["dish_id"]."'";
// Close connection
//mysqli_query($link, $sql);
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

mysqli_close($link);
?>